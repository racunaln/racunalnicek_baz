<?php  

  // Init session
  session_start();

  // Include db config
    require_once 'db.php';
  // Validate login
if(!isset($_SESSION['email']) || empty($_SESSION['email'])){
    header ('location:https://baz.racunalnicek.ga/prijava/index.php');
    }
    
  if(!isset($_SESSION['status']))
  {
    
  }
$ime= $_SESSION['ime'];
$priimek= $_SESSION['priimek'];
?>  
<html>
<head>
<style>
.body {
  margin: 10px;
  font-family: Arial, Helvetica, sans-serif;
}


.pregled_artiklov {
   margin: 10px; 
}
.navigacija {
    margin: 10px;
}
.nov_potni_nalog {
    margin:10px;
}

</style>
<meta charset="UTF-8">
<title>Računalniček baz - Stranke</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<script src="https://kit.fontawesome.com/0d0b1182e8.js" crossorigin="anonymous"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.css">
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCg4rES-cHvkyowz2QjYSS1aQi1vBJaYYM&libraries=places&callback=initAutocomplete" async defer></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css"> 
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
           <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
</head>
<body  onload="startTime()">

		
<?php
if($_SESSION['status'] == 'zaposleni')
{
?>
<div class="navigacija">
    <nav class="navbar navbar-expand-md navbar-light bg-light">
<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">

            <div class="navbar-nav">
                <a href="http://baz.racunalnicek.ga/zaposleni/" class="nav-item nav-link active">Domov</a>
               <a href="http://baz.racunalnicek.ga/zaposleni/stranke" class="nav-item nav-link">Stranke</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/porocila" class="nav-item nav-link">Poročila</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/dokumenti" class="nav-item nav-link">Vloge/dokumenti</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/klepet" class="nav-item nav-link">Klepet</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/potni_nalogi" class="nav-item nav-link">Potni nalogi</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/delovni_nalogi" class="nav-item nav-link">Delovni nalogi</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/prisotnost" class="nav-item nav-link">Prisotnost</a>
                <div class="nav-item dropdown">
                    <a href="http://baz.racunalnicek.ga/zaposleni/blagajna" class="nav-link dropdown-toggle" data-toggle="dropdown">Blagajna</a>
                    <div class="dropdown-menu">
                        <a href="http://baz.racunalnicek.ga/zaposleni/artikli" class="dropdown-item">Artikli</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/blagajna/ceniki" class="dropdown-item">Ceniki</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item">Pregled računov</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item">Nov račun</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item distabled">Davčna blagajna </a>
                    </div>  
                    </div>

                </div>
            </div>
            <div class="nav-item dropdown">
                    <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">Dobrodošli <?php echo $ime . " " . $priimek; ?></a>
                    <div class="dropdown-menu">
                    <img class="rounded mx-auto d-block" src="https://baz.racunalnicek.ga/prijava/slikeuporabnikov/<?php echo $_SESSION['avatar']?>" alt="<?php echo $_SESSION['name'] ?>" style="width:48px;height:48px; margin: center; border-radius: 50%;" /> <br />
                    E-poštni naslov: <?php echo $_SESSION['email']; ?> <br />
                    Oddelek: <?php echo $_SESSION['oddelek']; ?> <br />
                        <a  href="http://baz.racunalnicek.ga/zaposleni/moj_racun" class="dropdown-item">Moj račun</a>
                        <a href="http://baz.racunalnicek.ga/prijava/logout" class="dropdown-item">Odjava</a>
                    </div>
                </div>
        </div>
    </nav>
    <div class="nov_potni_nalog" ><a class="btn btn-primary" href="https://baz.racunalnicek.ga/zaposleni/potni_nalogi/nov.php">Nova potni nalog <i class='fas fa-plus'style='font-size:20px'></i></a></div>
  
<div class="pregled_artiklov">
<?php 
include_once 'db.php';
$result = mysqli_query($conn,"SELECT * FROM potni_nalogi");
?>
<input class="form-control" id="iskanje" type="text" placeholder="Išči po artiklih"><br />
<table class="table table-bordered">
    <thead>
      <tr>
        <th>Številka potnega naloga</th>
        <th>Izvajalec</th>
        <th>Skupaj potni stroški</th>
        <th>Možnosti</th>
      </tr>
    </thead>
    <tbody id="pregled_potnih_nalogov">
<?php
$i=0;
while ($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["stevilka_potnega_naloga"]; ?></td>
<?php
include_once 'db.php';
    $sql3="SELECT * FROM uporabniki WHERE id='".$row['id_zaposlenega']."'";
    $resultat = mysqli_query($conn, $sql3);
    $vrstica= mysqli_fetch_array($resultat);
?>
<td><?php echo $vrstica["ime"]." ".$vrstica["priimek"];  ?></td>
<?php
?>
<td><?php echo $row["skupaj_stroski"]; ?></td>
<td><a href="ogled?id=<?php echo $row["id"]; ?>">Ogled</a> <a href="izpis_potnega_naloga?id=<?php echo $row["id"]; ?>">Natisni</a></td>
</tr>
<?php
$i++;
}
?>
</tbody>
</table></div>
<script>
$(document).ready(function(){
  $("#iskanje").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#pregled_artiklov tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>
function startTime() {
  var today = new Date();
  var h = today.getHours();
  var m = today.getMinutes();
  var s = today.getSeconds();
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById('ura').innerHTML =
  h + ":" + m + ":" + s;
  var t = setTimeout(startTime, 500);
}
function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
}
</script>

<?php
}
?>
</body>
</html>