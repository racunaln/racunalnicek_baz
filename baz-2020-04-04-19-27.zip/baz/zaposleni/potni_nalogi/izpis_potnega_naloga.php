<?php
  session_start();
  // Validate login
  if(!isset($_SESSION['email']) || empty($_SESSION['email'])){
    header('location:https://baz.racunalnicek.ga/prijava/index.php');
    exit;
    }


require('fpdf.php');
include_once 'db.php';
$result = mysqli_query($conn,"SELECT * FROM potni_nalogi WHERE id='" . $_GET['id'] . "'");
$row= mysqli_fetch_array($result);
class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    // Arial bold 15
    $this->SetFont('Arial','',10);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(0,0,'Ra�unalni�ek',0,0,'L');
    // Line break
    $this->Ln(4);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Stran '.$this->PageNo().'',0,0,'C');
}
}

// Instanciation of inherited class
$pdf = new PDF();

$pdf->AliasNbPages();
$pdf->SetTitle('POTNI NALOG �t.: ' .$row['stevilka_potnega_naloga'].' ');
$pdf->AddPage();
$pdf->SetFont('Arial','B',13);
    $pdf->Cell(0,0,'POTNI NALOG �t.: ' .$row['stevilka_potnega_naloga'].' ',0,1);
    $pdf->SetFont('Arial','',9);
    $pdf->Cell(0,8,'�as izpisa ' . date("Y. m. d H:i:s").'',0,1);
    $pdf->Ln(5);
    $pdf->SetFont('Arial','',10);
    
    $pdf->Cell(0,4,'Ime in priimek/naziv: ' .$row['ime'].' '.$row['priimek']. '',0,1);
    $pdf->Cell(0,4,'Fizi�na oseba: ' .$row['fizicna_oseba'].'',0,1);
    $pdf->Cell(0,4,'Pravna oseba ' .$row['pravna_oseba'].'',0,1);
    $pdf->Cell(0,4,'Dav�ni zavezanec ' .$row['davcni_zavezanec']. '',0,1);
    $pdf->Cell(0,4,'Dobavitelj: ' .$row['dobavitelj']. '',0,1);
    $pdf->Cell(0,4,'Dav�na �tevilka ' .$row['davcna_stevilka']. '',0,1);
    $pdf->Cell(0,4,'Mati�na �tevilka ' .$row['maticna_stevilka'].'',0,1);
    $pdf->Cell(0,4,'Dejavnosti: ' .$row['dejavnosti']. '',0,1);
     $pdf->Ln(5);
    
    $pdf->Cell(0,4,'Naslovi stranke (poslovne enote, poslovalnice ...)',0,1);
    $pdf->Ln(2);
    $pdf->Cell(20,4,'Tip',1,0);
    $pdf->Cell(30,4,'Ulica/naslov',1,0);
    $pdf->Cell(40,4,'Po�tna �tevilka',1,0);
    $pdf->Cell(30,4,'Po�ta',1,0);
    $pdf->Cell(20,4,'Dr�ava',1,0);
    $pdf->Cell(50,4,'Opombe',1,1);
    include_once 'db.php';
$rezultat3 = mysqli_query($conn,"SELECT * FROM stranke_naslov WHERE id_stranke='" . $_GET['id'] . "' " );
$i=0;
while ($row = mysqli_fetch_array($rezultat3)) {
    $pdf->Cell(20,4,''.$row['tip'].'',1,0);
    $pdf->Cell(30,4,''.$row['naslov'].'',1,0);
    $pdf->Cell(40,4,''.$row['postna_stevilka'].'',1,0);
    $pdf->Cell(30,4,''.$row['posta'].'',1,0);
    $pdf->Cell(20,4,''.$row['drzava'].'',1,0);
    $pdf->Cell(0,4,''.$row['opombe'].'',1,1);
$i++;
}
$pdf->Ln(2);
$pdf->Cell(0,4,'Kontaktne informacije stranke',0,1);
$pdf->Ln(2);
    $pdf->Cell(35,4,'Kontaktna oseba',1,0);
    $pdf->Cell(41,4,'Email',1,0);
    $pdf->Cell(37,4,'Opombe email-u',1,0);
    $pdf->Cell(37,4,'Telefonska �tevilka',1,0);
    $pdf->Cell(0,4,'Opombe tel. �t.',1,1);

include_once 'db.php';
$rezultat4 = mysqli_query($conn,"SELECT * FROM stranke_kontakt WHERE id_stranke='" . $_GET['id'] . "' " );
$i=0;
while ($row = mysqli_fetch_array($rezultat4)) {
    $pdf->Cell(35,4,''.$row['kontaktna_oseba'].'',1,0);
    $pdf->Cell(41,4,''.$row['email'].'',1,0);
    $pdf->Cell(37,4,''.$row['opomba_email'].'',1,0);
    $pdf->Cell(37,4,''.$row['telefonska_stevilka'].'',1,0);
    $pdf->Cell(0,4,''.$row['opombe_telefonska_stevilka'].'',1,1);
$i++;
}

$pdf->Ln(30);
$pdf->Cell(0,4,'Dokument izdal: ' .$_SESSION['ime'].' '. $_SESSION['priimek']. '',0,1,'L');
$pdf->Ln(10);
$pdf->Cell(0,6,'_________________________________________',0,1);
$pdf->Cell(0,6,'               (Podpis izdajatelja dokumenta)',0,1);
$pdf->Output();
?>