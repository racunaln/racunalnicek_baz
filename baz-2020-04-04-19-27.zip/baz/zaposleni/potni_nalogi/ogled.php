<?php
  // Init session
  session_start();
  // Validate login
  if(!isset($_SESSION['email']) || empty($_SESSION['email'])){
    header('location:https://baz.racunalnicek.ga/prijava/index.php');
    exit;
    }
  if(!isset($_SESSION['status']))
  {
    
  }
$ime= $_SESSION['ime'];
$priimek= $_SESSION['priimek'];
?>  

<html>
<head>
<meta charset="UTF-8">
<title>Ra�unalni�ek baz</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<script src="https://kit.fontawesome.com/0d0b1182e8.js" crossorigin="anonymous"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.css">
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCg4rES-cHvkyowz2QjYSS1aQi1vBJaYYM&libraries=places&callback=initAutocomplete" async defer></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
<style>
.navigacija{
        margin: 10px;
    }
.ogled_potnega_naloga{
  margin: 10px;
  font-family: Arial, Helvetica, sans-serif;
}

</style>

</head>
<body>
		
<?php
if($_SESSION['status'] == 'zaposleni')
{
?>
<div class="navigacija">
    <nav class="navbar navbar-expand-md navbar-light bg-light">
<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">

            <div class="navbar-nav">
                <a href="http://baz.racunalnicek.ga/zaposleni/" class="nav-item nav-link active">Domov</a>
               <a href="http://baz.racunalnicek.ga/zaposleni/stranke" class="nav-item nav-link">Stranke</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/porocila" class="nav-item nav-link">Poro�ila</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/dokumenti" class="nav-item nav-link">Vloge/dokumenti</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/klepet" class="nav-item nav-link">Klepet</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/potni_nalogi" class="nav-item nav-link">Potni nalogi</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/delovni_nalogi" class="nav-item nav-link">Delovni nalogi</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/prisotnost" class="nav-item nav-link">Prisotnost</a>
                <div class="nav-item dropdown">
                    <a href="http://baz.racunalnicek.ga/zaposleni/blagajna" class="nav-link dropdown-toggle" data-toggle="dropdown">Blagajna</a>
                    <div class="dropdown-menu">
                        <a href="http://baz.racunalnicek.ga/zaposleni/artikli" class="dropdown-item">Artikli</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/blagajna/ceniki" class="dropdown-item">Ceniki</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item">Pregled ra�unov</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item">Nov ra�un</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item distabled">Dav�na blagajna </a>
                    </div>  
                    </div>

                </div>
            </div>
            <div class="nav-item dropdown">
                    <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">Dobrodo�li <?php echo $ime . " " . $priimek; ?></a>
                    <div class="dropdown-menu">
                    <img class="rounded mx-auto d-block" src="https://baz.racunalnicek.ga/prijava/slikeuporabnikov/<?php echo $_SESSION['avatar']?>" alt="<?php echo $_SESSION['name'] ?>" style="width:48px;height:48px; margin: center; border-radius: 50%;" /> <br />
                    E-po�tni naslov: <?php echo $_SESSION['email']; ?> <br />
                    Oddelek: <?php echo $_SESSION['oddelek']; ?> <br />
                        <a  href="http://baz.racunalnicek.ga/zaposleni/moj_racun" class="dropdown-item">Moj ra�un</a>
                        <a href="http://baz.racunalnicek.ga/prijava/logout" class="dropdown-item">Odjava</a>
                    </div>
                </div>
        </div>
        </div>
    </nav>
</div>
  <?php
include_once 'db.php';
$result = mysqli_query($conn,"SELECT * FROM potni_nalogi WHERE id='" . $_GET['id'] . "'");
$row= mysqli_fetch_array($result);
    $sql3="SELECT * FROM uporabniki WHERE id='".$row['id_zaposlenega']."'";
    $resultat = mysqli_query($conn, $sql3);
    $vrstica= mysqli_fetch_array($resultat);
if(isset($_POST['save'])){
    $id_zaposlenega = $_POST ['zaposleni'];
    $datum_zacetka = $_POST ['datum_zacetka'];
    $ura_zacetka = $_POST ['ura_zacetka'];
    $datum_konca = $_POST ['datum_konca'];
    $ura_konca = $_POST ['ura_konca'];
    $opis = $_POST ['opis'];
    $odobril = $_POST ['odobril'];
    $cena_na_km = $_POST ['cena_na_km'];
    $porocilo = $_POST ['porocilo'];
    $skupaj_kilometri = $_POST ['skupaj_kilometri'];
    $skupaj_stroski = $_POST ['skupaj_stroski'];
    $izdal = $ime." ".$priimek;
    $sql = "UPDATE potni_nalogi set id_zaposlenega='$id_zaposlenega', datum_zacetka='$datum_zacetka', ura_zacetka='$ura_zacetka', datum_konca='$datum_konca',ura_konca='$ura_konca',opis='$opis',odobril='$odobril',cena_na_km='$cena_na_km',porocilo='$porocilo',skupaj_kilometri='$skupaj_kilometri',skupaj_stroski='$skupaj_stroski' WHERE id= " . $_GET['id'] . ")";
$vstavi = mysqli_query($conn,$sql);
$last_id = $conn->insert_id;
if($vstavi==1) 
{
    
$potrdilo= "Uspe�no izdan!";
 }
 
else {$napaka;}
}


?>
<div class="ogled_potnega_naloga">
	<form id="ogled_potnega_naloga" name="ogled_potnega_naloga" method="post" action="" >
        <?php
$hostname = "localhost";
$username = "racunaln";
$password = "Patko1234.";
$databaseName = "racunaln_baz";
// connect to mysql database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);
// mysql select query
$query = "SELECT * FROM `uporabniki` WHERE status='zaposleni'";
$result = mysqli_query($connect, $query);

$options = "";

while($vrednost = mysqli_fetch_array($result))
{
    $options = $options."<option value=$vrednost[id]>$vrednost[ime] $vrednost[priimek]</option>";
}
	
?>


        <div class="form-group" >
			<label for="zaposleni">Zaposleni(izberite izvajalca)</label><br />
		 <select name="zaposleni" class="chosen">
         <option selected ><?php echo $vrstica["ime"]." ".$vrstica["priimek"]; ?></option>
            <?php echo $options;?>
        </select></div>
<?php
$result = mysqli_query($conn,"SELECT * FROM potni_nalogi WHERE id='" . $_GET['id'] . "'");
$vrednost= mysqli_fetch_array($result);	
?>
		<div class="form-inline">
			<label for="datum_zacetka">Datum za�etka</label>
			<input type="" class="form-control" id="datum_zacetka" value="<?php echo $row['datum_zacetka']; ?>" name="datum_zacetka" required="true">
			<label for="priimek">Ura za�etka</label>
			<input type="" class="form-control" id="ura_zacetka" value="<?php echo $row['ura_zacetka']; ?> "name="ura_zacetka">
		</div>
        	<div class="form-inline">
			<label for="datum_konca">Datum konca</label>
			<input type="" class="form-control" id="datum_konca" value="<?php echo $row['datum_konca']; ?>" name="datum_konca" required="true">
			<label for="ura_konca">Ura konca</label>
			<input type="" class="form-control" id="ura_konca" value="<?php echo $row['ura_konca']; ?>" name="ura_konca">
		</div>
 <div class="form-group" >
			<label for="opis">Opis</label>
		 <textarea class="form-control" rows="2" cols="1" id="opis" name="opis"><?php echo $row['opis']; ?></textarea>
        </div>
             <div class="form-group" >
			<label for="cena_na_km">Cena na kilometer</label><br />
			 <input name="cena_na_km" id="cena_na_km" class="form-control" value="<?php echo $row['cena_na_km']; ?>" />
		</div>
          <?php
$hostname = "localhost";
$username = "racunaln";
$password = "Patko1234.";
$databaseName = "racunaln_baz";
// connect to mysql database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);
// mysql select query
$query = "SELECT * FROM `uporabniki` WHERE status='zaposleni'";
$result = mysqli_query($connect, $query);

$options = "";

while($vrednost = mysqli_fetch_array($result))
{
    $options = $options."<option value=$vrednost[id]>$vrednost[ime] $vrednost[priimek]</option>";
}	
?>
        <div class="form-group" >
			<label for="odobril">Odobril</label><br />
		 <select style="width: 50%;" name="odobril" class="chosen">
         <option selected=""><?php echo $vrstica["ime"]." ".$vrstica["priimek"]; ?></option>
            <?php echo $options;?>
   </select>
   <div class="form-group" >
			<label for="porocilo">Poro�ilo</label>
		 <textarea class="form-control" rows="2" cols="1" id="porocilo" name="porocilo"><?php echo $row['porocilo']; ?></textarea>
        </div>
		</div>
                     <?php
$hostname = "localhost";
$username = "racunaln";
$password = "Patko1234.";
$databaseName = "racunaln_baz";
// connect to mysql database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);
// mysql select query
$query = "SELECT * FROM `potni_nalogi_vozila`";
$result = mysqli_query($connect, $query);

$options = "";

while($vrednost = mysqli_fetch_array($result))
{
    $options = $options."<option value=$vrednost[id]>$vrednost[prikazano_ime] $vrednost[registerska_stevilka] $vrednost[vrsta_vozila] $vrednost[lastnik]</option>";
}	
?>
        
                <div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<table class="table table-bordered table-hover" id="relacije">
                    <thead>
                         <tr>
							<th width="15%">Lokacija od</th>
							<th width="19%">Lokacija do</th>
                            <th width="20%">Vozilo</th>
                            <th width="20%">Skupaj kilometri</th>
                            <th width="20%">�as potovanja</th>
                            <th width="20%">Opombe</th>
                            
						</tr></thead>	
						<tbody>		
                        <?php
include_once 'db.php';
$result = mysqli_query($conn,"SELECT * FROM potni_nalogi_relacije WHERE id_potnega_naloga='" . $_GET['id'] . "'");
while ($destinacija = mysqli_fetch_array($result)) {
$sql3="SELECT * FROM potni_nalogi_vozila WHERE id='".$destinacija['vozilo']."'";
$rezultat3 = mysqli_query($conn, $sql3);
$vozilo= mysqli_fetch_array($rezultat3);
echo
'<tr>
							<td>'.$destinacija['od'].'</td>
							<td>'.$destinacija['do'].'</td>			
							<td>'.$vozilo['prikazano_ime']." ". $vozilo['registerska_stevilka']." ". $vozilo['naziv_vozila'].'</td>
							<td>'.$destinacija['skupaj_km'].'</td>
							<td>'.$destinacija['cas_potovanja'].'</td>
                            <td>'.$destinacija['opombe'].'</td>
						</tr>';
}	
?>
                        </tbody>							
					</table>
				</div></div>           
 </form></div>
 <script type="text/javascript">$(".chosen").chosen()</script>
<?php
}
?>