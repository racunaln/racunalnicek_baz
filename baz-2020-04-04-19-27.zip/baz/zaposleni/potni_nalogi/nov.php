<?php
  // Init session
  session_start();
  // Validate login
  if(!isset($_SESSION['email']) || empty($_SESSION['email'])){
    header('location:https://baz.racunalnicek.ga/prijava/index.php');
    exit;
    }
  if(!isset($_SESSION['status']))
  {
    
  }
$ime= $_SESSION['ime'];
$priimek= $_SESSION['priimek'];
?>  

<html>
<head>
<meta charset="UTF-8">
<title>Računalniček baz</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<script src="https://kit.fontawesome.com/0d0b1182e8.js" crossorigin="anonymous"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.css">
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCg4rES-cHvkyowz2QjYSS1aQi1vBJaYYM&libraries=places&callback=initAutocomplete" async defer></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
<style>
.navigacija{
        margin: 10px;
    }
.nov_potni_nalog {
  margin: 10px;
  font-family: Arial, Helvetica, sans-serif;
}

</style>

</head>
<body>
		
<?php
if($_SESSION['status'] == 'zaposleni')
{
?>
<div class="navigacija">
    <nav class="navbar navbar-expand-md navbar-light bg-light">
<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">

            <div class="navbar-nav">
                <a href="http://baz.racunalnicek.ga/zaposleni/" class="nav-item nav-link active">Domov</a>
               <a href="http://baz.racunalnicek.ga/zaposleni/stranke" class="nav-item nav-link">Stranke</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/porocila" class="nav-item nav-link">Poročila</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/dokumenti" class="nav-item nav-link">Vloge/dokumenti</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/klepet" class="nav-item nav-link">Klepet</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/potni_nalogi" class="nav-item nav-link">Potni nalogi</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/delovni_nalogi" class="nav-item nav-link">Delovni nalogi</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/prisotnost" class="nav-item nav-link">Prisotnost</a>
                <div class="nav-item dropdown">
                    <a href="http://baz.racunalnicek.ga/zaposleni/blagajna" class="nav-link dropdown-toggle" data-toggle="dropdown">Blagajna</a>
                    <div class="dropdown-menu">
                        <a href="http://baz.racunalnicek.ga/zaposleni/artikli" class="dropdown-item">Artikli</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/blagajna/ceniki" class="dropdown-item">Ceniki</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item">Pregled računov</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item">Nov račun</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item distabled">Davčna blagajna </a>
                    </div>  
                    </div>

                </div>
            </div>
            <div class="nav-item dropdown">
                    <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">Dobrodošli <?php echo $ime . " " . $priimek; ?></a>
                    <div class="dropdown-menu">
                    <img class="rounded mx-auto d-block" src="https://baz.racunalnicek.ga/prijava/slikeuporabnikov/<?php echo $_SESSION['avatar']?>" alt="<?php echo $_SESSION['name'] ?>" style="width:48px;height:48px; margin: center; border-radius: 50%;" /> <br />
                    E-poštni naslov: <?php echo $_SESSION['email']; ?> <br />
                    Oddelek: <?php echo $_SESSION['oddelek']; ?> <br />
                        <a  href="http://baz.racunalnicek.ga/zaposleni/moj_racun" class="dropdown-item">Moj račun</a>
                        <a href="http://baz.racunalnicek.ga/prijava/logout" class="dropdown-item">Odjava</a>
                    </div>
                </div>
        </div>
        </div>
    </nav>
</div>
  <?php
include_once 'db.php';
if(isset($_POST['save'])){
    $id_zaposlenega = $_POST ['zaposleni'];
    $datum_zacetka = $_POST ['datum_zacetka'];
    $ura_zacetka = $_POST ['ura_zacetka'];
    $datum_konca = $_POST ['datum_konca'];
    $ura_konca = $_POST ['ura_konca'];
    $opis = $_POST ['opis'];
    $odobril = $_POST ['odobril'];
    $cena_na_km = $_POST ['cena_na_km'];
    $porocilo = $_POST ['porocilo'];
    $skupaj_kilometri = $_POST ['skupaj_kilometri'];
    $skupaj_stroski = $_POST ['skupaj_stroski'];
    $izdal = $ime." ".$priimek;
    $sql = "INSERT INTO potni_nalogi ( id_zaposlenega, datum_zacetka, ura_zacetka, datum_konca,ura_konca,opis,odobril,cena_na_km,porocilo,skupaj_kilometri,skupaj_stroski, izdal)
	 VALUES ('$id_zaposlenega','$datum_zacetka','$ura_zacetka','$datum_konca','$ura_konca','$opis','$odobril','$cena_na_km','$porocilo','$skupaj_kilometri','$skupaj_stroski', '$izdal')";
$vstavi = mysqli_query($conn,$sql);
$last_id = $conn->insert_id;
if($vstavi==1){ 
for ($i = 0; $i < count($_POST['lokacija_od']); $i++){
$sql1= "INSERT INTO potni_nalogi_relacije (od, do, vozilo, skupaj_km, cas_potovanja, opombe, id_potnega_naloga) 
VALUES ( '".$_POST['lokacija_od'][$i]."', '".$_POST['lokacija_do'][$i]."', '".$_POST['vozilo'][$i]."', '".$_POST['skupaj_km'][$i]."','".$_POST['cas_potovanja'][$i]."','".$_POST['opombe'][$i]."', '$last_id')";
$vstavi3= mysqli_query($conn, $sql1);}    
if($vstavi3==1){
    
$potrdilo= "Uspešno izdan!";
 }
 
else {$napaka;}
}} 
?>
<div class="nov_potni_nalog">

<div><?php if(isset($potrdilo)) {?> <div class="alert alert-success alert-dismissible">
  <strong>Potrdilo</strong> <?php echo $potrdilo;?> </div> <?php }?>
</div>
<div><?php if(isset($napaka)) {?> <div class="alert alert-danger alert-dismissible">
  <strong>Težava</strong> </div> <?php }?>
</div>
<div style="margin-left: 10px;">Nov potni nalog</div>
	<form id="nov_potni_nalog" name="nov_potni_nalog" method="post" action="" >
        <?php
$hostname = "localhost";
$username = "racunaln";
$password = "Patko1234.";
$databaseName = "racunaln_baz";
// connect to mysql database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);
// mysql select query
$query = "SELECT * FROM `uporabniki` WHERE status='zaposleni'";
$result = mysqli_query($connect, $query);

$options = "";

while($row = mysqli_fetch_array($result))
{
    $options = $options."<option value=$row[id]>$row[ime] $row[priimek]</option>";
}	
?>
        <div class="form-group" >
			<label for="zaposleni">Zaposleni(izberite izvajalca)</label><br />
		 <select name="zaposleni" class="chosen">
            <?php echo $options;?>
        </select>
		<div class="form-inline">
			<label for="datum_zacetka">Datum začetka</label>
			<input type="" class="form-control" id="datum_zacetka" placeholder="Vnesite datum začetka" name="datum_zacetka" required="true">
			<label for="ura_zacetka">Ura začetka</label>
			<input type="" class="timepicker" id="ura_zacetka" placeholder="Vnesite uro začetka" name="ura_zacetka">
		</div>
        	<div class="form-inline">
			<label for="datum_konca">Datum konca</label>
			<input type="" class="form-control" id="datum_konca" placeholder="Vnesite datum konca" name="datum_konca" required="true">
			<label for="ura_konca">Ura konca</label>
			<input type="" class="timepicker" id="ura_konca" placeholder="Vnesite uro začetka" name="ura_konca">
		</div>
 <div class="form-group" >
			<label for="opis">Opis</label>
		 <textarea class="form-control" rows="2" cols="1" id="opis" name="opis"></textarea>
        </div>
             <div class="form-group" >
			<label for="cena_na_km">Cena na kilometer</label><br />
			 <input name="cena_na_km" id="cena_na_km" class="form-control" />
		</div>
          <?php
$hostname = "localhost";
$username = "racunaln";
$password = "Patko1234.";
$databaseName = "racunaln_baz";
// connect to mysql database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);
// mysql select query
$query = "SELECT * FROM `uporabniki` WHERE status='zaposleni'";
$result = mysqli_query($connect, $query);

$options = "";

while($odobril_seznam = mysqli_fetch_array($result))
{
    $options = $options."<option value=$odobril_seznam[id]>$odobril_seznam[ime] $odobril_seznam[priimek]</option>";
}	
?>
        <div class="form-group" >
			<label for="odobril">Odobril</label><br />
		 <select style="width: 50%;" name="odobril" class="chosen">
            <?php echo $options;?>
   </select>
   <div class="form-group" >
			<label for="porocilo">Poročilo</label>
		 <textarea class="form-control" rows="2" cols="1" id="porocilo" name="porocilo"></textarea>
        </div>
		</div>
                     <?php
$hostname = "localhost";
$username = "racunaln";
$password = "Patko1234.";
$databaseName = "racunaln_baz";
// connect to mysql database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);
// mysql select query
$query = "SELECT * FROM `potni_nalogi_vozila`";
$result = mysqli_query($connect, $query);

$options = "";

while($row = mysqli_fetch_array($result))
{
    $options = $options."<option value=$row[id]>$row[prikazano_ime] $row[registerska_stevilka] $row[vrsta_vozila] $row[lastnik]</option>";
}	
?>
        
                <div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<table class="table table-bordered table-hover" id="relacije">	
						<tr>
							<th width="1%"><input id="checkAll" class="formcontrol" type="checkbox"></th>
							<th width="15%">Lokacija od</th>
							<th width="19%">Lokacija do</th>
                            <th width="20%">Vozilo</th>
                            <th width="20%">Skupaj kilometri</th>
                            <th width="20%">Čas potovanja</th>
                            <th width="20%">Opombe</th>
                            
						</tr>							
						<tr>
							<td><input class="relacije_vrstice" type="checkbox"></td>
							<td><input type="text" name="lokacija_od[]" id="lokacija_od_1" class="form-control" autocomplete="off"></td>
							<td><input type="text" name="lokacija_do[]" id="lokacija_do_1" class="form-control" autocomplete="off"></td>			
							<td><select style="width: 100%;"name="vozilo[]" class="chosen" id="vozilo_1"><?php echo $options;?></select></td>
							<td><input type="text" name="skupaj_km[]" id="skupaj_km_1" class="form-control" autocomplete="off"></td>
							<td><input type="text" name="cas_potovanja[]" id="cas_potovanja_1" class="form-control" autocomplete="off"></td>
                            <td><input type="text" name="opombe[]" id="opombe_1" class="form-control" autocomplete="off"></td>
						</tr>						
					</table>
				</div></div>
			
				<div class="row">
				<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
					<button class="btn btn-danger delete" id="izbrisi_relacijo" type="button">-Izbriši relacijo</button>
					<button class="btn btn-success" id="dodaj_relacijo" type="button">+ Dodaj relacijo</button><br />
				</div>
    <div class="row"><br /><input  type="submit" name="save" value="Dodaj potni nalog" class="btn btn-primary"> </div>            
 </form></div>
 <script type="text/javascript">$(".chosen").chosen()</script>
 <script>
$(document).ready(function(){
	$(document).on('click', '#checkAll', function() {          	
		$(".relacije_vrstice").prop("checked", this.checked);
	});	
	$(document).on('click', '.relacije_vrstice', function() {  	
		if ($('.relacije_vrstice:checked').length == $('.relacije_vrstice').length) {
			$('#checkAll').prop('checked', true);
		} else {
			$('#checkAll').prop('checked', false);
		}
	});  
	var count = $(".relacije_vrstice").length;
	$(document).on('click', '#dodaj_relacijo', function() { 
		count++;
		var htmlRows = '';
		htmlRows += '<tr>';
		htmlRows += '<td><input class="relacije_vrstice" type="checkbox"></td>';          
		htmlRows += '<td><input type="text" name="lokacija_od[]" id="lokacija_od_'+count+'" class="form-control" autocomplete="off"></td>';							
        htmlRows += '<td><input type="text" name="lokacija_do[]" id="lokacija_do_'+count+'" class="form-control" autocomplete="off"></td>';
		htmlRows += '<td><select name="vozilo[]" class="chosen" id="vozilo_'+count+'"><?php echo $options;?></select></td>';
        htmlRows += '<td><input type="text" name="skupaj_km[]" id="skupaj_km_'+count+'" class="form-control" autocomplete="off"></td>';   				 
		htmlRows += '<td><input type="text" name="cas_potovanja[]" id="cas_potovanja_'+count+'" class="form-control" autocomplete="off"></td>'; 
        htmlRows += '<td><input type="text" name="opombe[]" id="opombe_'+count+'" class="form-control" autocomplete="off"></td>';     
		htmlRows += '</tr>';

        
		$('#relacije').append(htmlRows);
	}); 
	$(document).on('click', '#izbrisi_relacijo', function(){
		$(".relacije_vrstice:checked").each(function() {
			$(this).closest('tr').remove();
		});
		$('#checkAll').prop('checked', false);
		calculateTotal();
	});			


	
});	

  $( function() {
    $( "#datum_zacetka" ).datepicker({dateFormat: 'dd.mm.yy'});
  } );
    $( function() {
    $( "#datum_konca" ).datepicker({dateFormat: 'dd. mm. yy'});
  } );
 

$(document).ready(function(){
$('input.timepicker').timepicker({
    timeFormat: 'HH:mm',
    interval: '1',
    dynamic: true,
    dropdown: true,
    scrollbar: true
});

});

 
  
</script>

<?php
}
?>
</body>
</html>