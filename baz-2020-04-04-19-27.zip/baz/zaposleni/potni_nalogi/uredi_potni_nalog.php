<?php  
//action.php
$connect = mysqli_connect('localhost', 'racunaln', 'Patko1234.', 'racunaln_baz');

$input = filter_input_array(INPUT_POST);



if($input["action"] === 'edit')
{
 $query = "UPDATE potni_nalogi_relacije 
 SET od = '".$input["od"]."', do='".$input["do"]."', skupaj_km= '".$input["skupaj_km"]."', cas_potovanja= '".$input["cas_potovanja"]."',  opombe= '".$input["opombe"]."' 
 WHERE id = '".$input["id"]."'
 ";

 mysqli_query($connect, $query);

}
if($input["action"] === 'delete')
{
 $query = "
 DELETE FROM potni_nalogi_relacije 
 WHERE id = '".$input["id"]."'
 ";
 mysqli_query($connect, $query);
}

echo json_encode($input);