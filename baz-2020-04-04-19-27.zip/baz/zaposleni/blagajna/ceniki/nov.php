<?php
  // Init session
  session_start();
  // Validate login
  if(!isset($_SESSION['email']) || empty($_SESSION['email'])){
    header('location:https://baz.racunalnicek.ga/prijava/index.php');
    exit;
    }
  if(!isset($_SESSION['status']))
  {
    
  }
$ime= $_SESSION['ime'];
$priimek= $_SESSION['priimek'];
?>  

<html>
<head>
<meta charset="UTF-8">
<title>Ra�unalni�ek baz</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<script src="https://kit.fontawesome.com/0d0b1182e8.js" crossorigin="anonymous"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.css">
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCg4rES-cHvkyowz2QjYSS1aQi1vBJaYYM&libraries=places&callback=initAutocomplete" async defer></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<style>
.navigacija{
        margin: 10px;
    }
.nov_cenik {
  margin: 10px;
  font-family: Arial, Helvetica, sans-serif;
}

</style>

</head>
<body>
		
<?php
if($_SESSION['status'] == 'zaposleni')
{
?>
<div class="navigacija">
    <nav class="navbar navbar-expand-md navbar-light bg-light">
<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">

            <div class="navbar-nav">
                <a href="http://baz.racunalnicek.ga/zaposleni/" class="nav-item nav-link active">Domov</a>
               <a href="http://baz.racunalnicek.ga/zaposleni/stranke" class="nav-item nav-link">Stranke</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/porocila" class="nav-item nav-link">Poro�ila</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/dokumenti" class="nav-item nav-link">Vloge/dokumenti</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/klepet" class="nav-item nav-link">Klepet</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/potni_nalogi" class="nav-item nav-link">Potni nalogi</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/delovni_nalogi" class="nav-item nav-link">Delovni nalogi</a>
                <a href="http://baz.racunalnicek.ga/zaposleni/prisotnost" class="nav-item nav-link">Prisotnost</a>
                <div class="nav-item dropdown">
                    <a href="http://baz.racunalnicek.ga/zaposleni/blagajna" class="nav-link dropdown-toggle" data-toggle="dropdown">Blagajna</a>
                    <div class="dropdown-menu">
                        <a href="http://baz.racunalnicek.ga/zaposleni/artikli" class="dropdown-item">Artikli</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/blagajna/ceniki" class="dropdown-item">Ceniki</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item">Pregled ra�unov</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item">Nov ra�un</a>
                        <a href="http://baz.racunalnicek.ga/zaposleni/racuni" class="dropdown-item distabled">Dav�na blagajna </a>
                    </div>  
                    </div>

                </div>
            </div>
            <div class="nav-item dropdown">
                    <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">Dobrodo�li <?php echo $ime . " " . $priimek; ?></a>
                    <div class="dropdown-menu">
                    <img class="rounded mx-auto d-block" src="https://baz.racunalnicek.ga/prijava/slikeuporabnikov/<?php echo $_SESSION['avatar']?>" alt="<?php echo $_SESSION['name'] ?>" style="width:48px;height:48px; margin: center; border-radius: 50%;" /> <br />
                    E-po�tni naslov: <?php echo $_SESSION['email']; ?> <br />
                    Oddelek: <?php echo $_SESSION['oddelek']; ?> <br />
                        <a  href="http://baz.racunalnicek.ga/zaposleni/moj_racun" class="dropdown-item">Moj ra�un</a>
                        <a href="http://baz.racunalnicek.ga/prijava/logout" class="dropdown-item">Odjava</a>
                    </div>
                </div>
        </div>
        </div>
    </nav>
</div>
  <?php
include_once 'db.php';
if(isset($_POST['save'])){
    $naziv_cenika=$_POST['naziv_cenika'];
    
	 $sql = "INSERT INTO ceniki (naziv_cenika, priimek, pravna_oseba, fizicna_oseba,davcni_zavezanec,dobavitelj,stranka,davcna_stevilka,maticna_stevilka,dejavnosti,spletna_stran, sifra_stranke)
	 VALUES ('$ime','$priimek','$pravna_oseba','$fizicna_oseba','$davcni_zavezanec','$dobavitelj','$stranka','$davcna_stevilka','$maticna_stevilka','$dejavnosti','$spletna_stran', '$sifra_stranke')";
            $vstavi = mysqli_query($conn,$sql) or die (mysqli_error($conn));
             $last_id = $conn->insert_id;
             if($vstavi==1){
             $sql3= "INSERT INTO uporabniki (sifra_stranke, email, ime, priimek, password, status, id_stranke) 
VALUES ('$sifra_stranke', '$elektronski_naslov_za_prijavo','$ime','$priimek','$sifrirano_geslo', 'stranka', '$last_id')";
$vstavi2= mysqli_query($conn, $sql3) or die (mysqli_error($conn));  
 if($vstavi2==1){  
    for ($i = 0; $i < count($_POST['tip']); $i++){
 $sql1= "INSERT INTO stranke_naslov (sifra_stranke, tip, naslov, posta, postna_stevilka, drzava, opombe, id_stranke) 
VALUES ('$sifra_stranke', '".$_POST['tip'][$i]."', '".$_POST['naslov'][$i]."', '".$_POST['posta'][$i]."', '".$_POST['postna_stevilka'][$i]."','".$_POST['drzava'][$i]."','".$_POST['opombe'][$i]."', '$last_id')";
$vstavi3= mysqli_query($conn, $sql1) or die (mysqli_error($conn));}    
if($vstavi3==1){ for ($a = 0; $a < count($_POST['kontaktna_oseba']); $a++){
 $sql2= "INSERT INTO stranke_kontakt (sifra_stranke, email, telefonska_stevilka, opombe_telefonska_stevilka, kontaktna_oseba, opomba_email, id_stranke) 
VALUES ('$sifra_stranke', '".$_POST['email'][$a]."', '".$_POST['telefonska_stevilka'][$a]."', '".$_POST['opombe_telefonska_stevilka'][$a]."', '".$_POST['kontaktna_oseba'][$a]."','".$_POST['opomba_email'][$a]."', '$last_id')";
 $vstavi4=mysqli_query($conn, $sql2) or die (mysqli_error($conn));
 if($vstavi4==1){
    
$potrdilo= "Uspe�no dodana stranka!";
// the message
}} }   }


}} 
    ?>
<div class="nov_cenik">

<div><?php if(isset($potrdilo)) {?> <div class="alert alert-success alert-dismissible">
  <strong>Potrdilo</strong> <?php echo $potrdilo;?> </div> <?php }?>
</div>
	<form id="nov_cenik" name="nov_cenik" method="post" action="" >
    <div class="form-group">
			<label for="sifra_cenika">�ifra cenika</label>
			<input type="text" class="form-control" id="sifra_cenika" placeholder="Vnesite �ifro cenika" name="sifra_cenika">
		</div>
		<div class="form-group">
			<label for="ime">Naziv cenika</label>
			<input type="text" class="form-control" id="naziv_cenika" placeholder="Vnesite naziv cenika" name="naziv_cenika" required="true">
		</div>
		<div class="form-inline">
			<label for="velja_od">Velja od</label>
			<input type="date" class="form-control" id="velja_od" name="velja_od">
			<label for="velja_do">Velja do</label>
     <input type="date" class="form-control" id="velja_do" name="velja_do">
		</div>
		<div class="form-group" >Valuta</label>
             <select style="width: 50%;" class="js-example-basic-single" name="valuta" id="valuta" required>
             <option value="EUR - Evro">EUR - Evro</option>
  </select>
        <?php
$hostname = "localhost";
$username = "racunaln";
$password = "Patko1234.";
$databaseName = "racunaln_baz";
// connect to mysql database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);
// mysql select query
$query = "SELECT * FROM `artikli`";
$result = mysqli_query($connect, $query);
$options = "";

while($row = mysqli_fetch_array($result))
{
    $options = $options."<option  value=$row[id]>$row[naziv_artikla] $row[opis]</option>";
}	
?>
                <div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<table class="table table-bordered table-hover" id="naslovi">	
						<tr>
							<th width="1%"><input id="checkAll" class="formcontrol" type="checkbox"></th>
							<th width="15%">Artikel</th>
							<th width="19%">Nabavna cena</th>
							<th width="15%">Cena brez DDV</th>
							<th width="15%">DDV (%)</th>								
							<th width="15%">Cena z DDV</th>
                            <th width="15%">Kon�na cena</th>
                            <th width="20%">Opombe</th>
						</tr>							
						<tr>
							<td><input class="artikli_vrstice" type="checkbox"></td>
							<td><select name="artikel" class="js-example-basic-single"><?php echo $options;?></select></td>
							<td><input type="text" name="nabavna_cena[]" id="nabavna_cena_1" class="form-control" autocomplete="off"></td>			
							<td><input type="text" name="cena_brez_ddv[]" id="cena_brez_ddv_1" class="form-control" autocomplete="off"></td>
							<td><input type="text" name="ddv[]" id="ddv_1" class="form-control" autocomplete="off"></td>
							<td><input type="text" name="cena_z_ddv[]" id="cena_z_ddv_1" class="form-control" autocomplete="off"></td>
                            <td><input type="text" name="koncna_cena[]" id="koncna_cena_1" class="form-control" autocomplete="off"></td>
                            <td><input type="text" name="opombe[]" id="opombe_1" class="form-control" autocomplete="off"></td>
						</tr>						
					</table>
				</div></div>
			
				<div class="row">
				<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
					<button class="btn btn-danger delete" id="izbrisi_naslov" type="button">-Izbri�i vrstico</button>
					<button class="btn btn-success" id="dodaj_naslov" type="button">+ Dodaj naslov</button><br />
				</div>
    <div class="row"><br /><input  type="submit" name="save" value="Dodaj stranko" class="btn btn-primary"> </div>            
 </form></div>
 <script type="text/javascript">$(".chosen").chosen()
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});	


$(document).ready(function(){
	$(document).on('click', '#checkAll', function() {          	
		$(".artikli_vrstice").prop("checked", this.checked);
	});	
	$(document).on('click', '.artikli_vrstice', function() {  	
		if ($('.artikli_vrstice:checked').length == $('.artikli_vrstice').length) {
			$('#checkAll').prop('checked', true);
		} else {
			$('#checkAll').prop('checked', false);
		}
	});  
	var count = $(".artikli_vrstice").length;
	$(document).on('click', '#dodaj_naslov', function() { 
		count++;
		var htmlRows = '';
		htmlRows += '<tr>';
		htmlRows += '<td><input class="artikli_vrstice" type="checkbox"></td>';          
		htmlRows += '<td><select name="dejavnosti" class=""><?php echo $options;?></select></td>';							
        htmlRows += '<td><input type="text" name="naslov[]" id="naslov_'+count+'" class="form-control" autocomplete="off"></td>';
		htmlRows += '<td><input type="text" name="postna_stevilka[]" id="postna_stevilka_'+count+'" class="form-control" autocomplete="off"></td>';
        htmlRows += '<td><input type="text" name="posta[]" id="posta_'+count+'" class="form-control" autocomplete="off"></td>';   				 
		htmlRows += '<td><input type="text" name="drzava[]" id="drzava_'+count+'" class="form-control" autocomplete="off"></td>'; 
        htmlRows += '<td><input type="text" name="opombe[]" id="opombe_'+count+'" class="form-control" autocomplete="off"></td>';     
		htmlRows += '</tr>';

        
		$('#naslovi').append(htmlRows);
	}); 
	$(document).on('click', '#izbrisi_naslov', function(){
		$(".artikli_vrstice:checked").each(function() {
			$(this).closest('tr').remove();
		});
		$('#checkAll').prop('checked', false);
		calculateTotal();
	});			

});

	
</script>

<?php
}
?>
</body>
</html>