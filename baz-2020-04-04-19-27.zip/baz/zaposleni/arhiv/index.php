
<?php
  // Init session
  session_start();

  // Include db config
  require_once 'db.php';
  // Validate login
  if(!isset($_SESSION['email']) || empty($_SESSION['email'])){
    header('location:https://baz.racunalnicek.ga/prijava/login.php');
    exit;
    }
    
  if(!isset($_SESSION['status']))
  {
    
  }
?>  
<html>
<head>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
.topnav-right {
  float: right;
}
.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 20px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.arhiv{ text-align: left;

}
}
</style>
<title>Ra�unalni�ek baz</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>

</head>
<body>


<?php

	if($_SESSION['status'] == 'stranka')
{
?>  
	Ni dostopa
<?php
}
?>
		
<?php
if($_SESSION['status'] == 'zaposleni')
{
?>
<!-- Section CSS -->
	<!-- jQuery UI (REQUIRED) -->
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/jquery/jquery-ui-1.12.0.css" type="text/css">

	<!-- elfinder css -->
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/commands.css"    type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/common.css"      type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/contextmenu.css" type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/cwd.css"         type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/dialog.css"      type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/fonts.css"       type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/navbar.css"      type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/places.css"      type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/quicklook.css"   type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/statusbar.css"   type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/theme.css"       type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/toast.css"       type="text/css">
	<link rel="stylesheet" href="https://baz.racunalnicek.ga/file/css/toolbar.css"     type="text/css">

	<!-- Section JavaScript -->
	<!-- jQuery and jQuery UI (REQUIRED) -->
	<script src="https://baz.racunalnicek.ga/file/jquery/jquery-1.12.4.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://baz.racunalnicek.ga/file/jquery/jquery-ui-1.12.0.js" type="text/javascript" charset="utf-8"></script>

	<!-- elfinder core -->
	<script src="https://baz.racunalnicek.ga/file/js/elFinder.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/elFinder.version.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/jquery.elfinder.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/elFinder.mimetypes.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/elFinder.options.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/elFinder.options.netmount.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/elFinder.history.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/elFinder.command.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/elFinder.resources.js"></script>

	<!-- elfinder dialog -->
	<script src="https://baz.racunalnicek.ga/file/js/jquery.dialogelfinder.js"></script>

	<!-- elfinder default lang -->
	<script src="https://baz.racunalnicek.ga/file/js/i18n/elfinder.en.js"></script>

	<!-- elfinder ui -->
	<script src="https://baz.racunalnicek.ga/file/js/ui/button.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/contextmenu.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/cwd.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/dialog.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/fullscreenbutton.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/navbar.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/navdock.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/overlay.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/panel.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/path.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/places.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/searchbutton.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/sortbutton.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/stat.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/toast.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/toolbar.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/tree.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/uploadButton.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/viewbutton.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/ui/workzone.js"></script>

	<!-- elfinder commands -->
	<script src="https://baz.racunalnicek.ga/file/js/commands/archive.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/back.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/chmod.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/colwidth.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/copy.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/cut.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/download.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/duplicate.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/edit.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/empty.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/extract.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/forward.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/fullscreen.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/getfile.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/help.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/hidden.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/hide.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/home.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/info.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/mkdir.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/mkfile.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/netmount.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/open.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/opendir.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/opennew.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/paste.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/places.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/preference.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/quicklook.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/quicklook.plugins.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/reload.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/rename.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/resize.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/restore.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/rm.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/search.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/selectall.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/selectinvert.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/selectnone.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/sort.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/undo.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/up.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/upload.js"></script>
	<script src="https://baz.racunalnicek.ga/file/js/commands/view.js"></script>

	<!-- elfinder 1.x connector API support (OPTIONAL) -->
	<script src="https://baz.racunalnicek.ga/file/js/proxy/elFinderSupportVer1.js"></script>

	<!-- Extra contents editors (OPTIONAL) -->
	<script src="https://baz.racunalnicek.ga/file/js/extras/editors.default.js"></script>

	<!-- GoogleDocs Quicklook plugin for GoogleDrive Volume (OPTIONAL) -->
	<script src="https://baz.racunalnicek.ga/file/js/extras/quicklook.googledocs.js"></script>

	<!-- elfinder initialization  -->
	<script>
		$(function() {
			$('#elfinder').elfinder(
				// 1st Arg - options
				{
					// Disable CSS auto loading
					cssAutoLoad : false,

					// Base URL to css/*, js/*
					baseUrl : '.http://baz.racunalnicek.ga/racunalnicekbaz/file/',

					// Connector URL
					url : 'https://baz.racunalnicek.ga/file/php/connector.minimal.php',

					// Callback when a file is double-clicked
					getFileCallback : function(file) {
						// ...
					},
				},
				
				// 2nd Arg - before boot up function
				function(fm, extraObj) {
					// `init` event callback function
					fm.bind('init', function() {
						// Optional for Japanese decoder "extras/encoding-japanese.min"
						delete fm.options.rawStringDecoder;
						if (fm.lang === 'ja') {
							fm.loadScript(
								[ fm.baseUrl + 'https://baz.racunalnicek.ga/file/js/extras/encoding-japanese.min.js' ],
								function() {
									if (window.Encoding && Encoding.convert) {
										fm.options.rawStringDecoder = function(s) {
											return Encoding.convert(s,{to:'UNICODE',type:'string'});
										};
									}
								},
								{ loadType: 'tag' }
							);
						}
					});
					
					// Optional for set document.title dynamically.
					var title = document.title;
					fm.bind('open', function() {
						var path = '',
							cwd  = fm.cwd();
						if (cwd) {
							path = fm.path(cwd.hash) || null;
						}
						document.title = path? path + ':' + title : title;
					}).bind('destroy', function() {
						document.title = title;
					});
				}
			);
		});
	</script>
<div class="topnav">
  <a class="active" href="http://baz.racunalnicek.ga/zaposleni/">Domov</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/stranke">Stranke</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/skladisce">Skladi��e</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/porocila">Poro�ila</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/blagajna">Blagajna</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/artikli">Artikli</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/arhiv">Arhiv</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/email">E - po�ta</a>
  <div class="topnav-right">
     <div class="dropdown">
    <button class="dropbtn">Dobrodo�el <?php echo $_SESSION['name']; ?>
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
    Epo�tni naslov: <?php echo $_SESSION['email']; ?>
    Oddelek: <?php echo $_SESSION['oddelek']; ?>
      <a href="https://baz.racunalnicek.ga/zaposleni/moj_racun">Moj ra�un</a>
      <a href="https://baz.racunalnicek.ga/prijava/logout.php">Odjava</a>
    </div>
  </div> 
  </div>
  </div>
  <div class="arhiv"> <h1>Arhiv</h1></div>
  <div class= "opis"><p>Arhiv je namenjen shranjevanju SKUPNIH DOKUMENTOV.</p><br>
  <p>Vsi dokumenti so dostopni vsem zaposlenim.</p></div>
 <div id="elfinder"></div>
<?php
}
?>
</body>
</html>