<?php
  // Init session
  session_start();

  // Include db config
  require_once 'db.php';
  // Validate login
  if(!isset($_SESSION['email']) || empty($_SESSION['email'])){
    header('location:https://baz.racunalnicek.ga/prijava/login.php');
    exit;
    }
    
  if(!isset($_SESSION['status']))
  {
    
  }
?>  
<html>
<head>		
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
        <link rel="stylesheet" href="https://cdn.rawgit.com/mervick/emojionearea/master/dist/emojionearea.min.css"/>
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  		<script src="https://cdn.rawgit.com/mervick/emojionearea/master/dist/emojionearea.min.js"></script>
  		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.js"></script>
    
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
.topnav-right {
  float: right;
}
.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 20px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
.chat_message_area
{
	position: relative;
	width: 100%;
	height: auto;
	background-color: #FFF;
    border: 1px solid #CCC;
    border-radius: 3px;
}

#group_chat_message
{
	width: 100%;
	height: auto;
	min-height: 80px;
	overflow: auto;
	padding:6px 24px 6px 12px;
}

.image_upload
{
	position: absolute;
	top:3px;
	right:3px;
}
.image_upload > form > input
{
    display: none;
}

.image_upload img
{
    width: 24px;
    cursor: pointer;
}
</style>
<title>Računalniček baz - Klepet</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
</head>
<body>


<?php

	if($_SESSION['status'] == 'stranka')
{
?>  
	Ni dostopa
<?php
}
?>
		
<?php
if($_SESSION['status'] == 'zaposleni')
{
?>
<div class="topnav">
  <a class="active" href="https://baz.racunalnicek.ga/zaposleni/">Domov</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/stranke">Stranke</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/skladisce">Skladišče</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/porocila">Poročila</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/blagajna">Blagajna</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/artikli">Artikli</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/arhiv">Arhiv</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/email">E - pošta</a>7
  <a href="https://baz.racunalnicek.ga/zaposleni/klepet">Klepet</a>
  <div class="topnav-right">
     <div class="dropdown">
    <button class="dropbtn">Dobrodošel <?php echo $_SESSION['name']; ?>
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
    Epoštni naslov: <?php echo $_SESSION['email']; ?>
    Oddelek: <?php echo $_SESSION['oddelek']; ?>
      <a href="https://baz.racunalnicek.ga/zaposleni/moj_racun">Moj račun</a>
      <a href="https://baz.racunalnicek.ga/prijava/logout.php">Odjava</a>
    </div>
  </div> 
  </div>
  </div>

  
<?php
}
?>
</body>
</html>