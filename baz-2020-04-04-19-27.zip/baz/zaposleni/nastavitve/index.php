<?php
  // Init session
  session_start();

  // Include db config
  require_once 'db.php';
  // Validate login
  if(!isset($_SESSION['email']) || empty($_SESSION['email'])){
    header('location:https://baz.racunalnicek.ga/prijava/index.php');
    exit;
    }
    
  if(!isset($_SESSION['status']))
  {
    
  }
?>  
<html>
<head>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
.topnav-right {
  float: right;
}
.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 20px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
</style>
<title>Ra�unalni�ek baz</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
</head>
<body>

<?php

	if($_SESSION['status'] == 'stranka')
{
?>  
	Ni dostopa
<?php
}
?>
		
<?php
if($_SESSION['status'] == 'zaposleni')
{
?>
<div class="topnav">
  <a class="active" href="https://baz.racunalnicek.ga/zaposleni/">Domov</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/stranke">Stranke</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/skladisce">Skladi��e</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/porocila">Poro�ila</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/blagajna">Blagajna</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/artikli">Artikli</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/arhiv">Arhiv</a>
  <a href="https://baz.racunalnicek.ga/zaposleni/email">E - po�ta</a>
  <div class="topnav-right">
     <div class="dropdown">
    <button class="dropbtn">Dobrodo�el <?php echo $_SESSION['name']; ?>
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
    Epo�tni naslov: <?php echo $_SESSION['email']; ?>
    Oddelek: <?php echo $_SESSION['oddelek']; ?>
      <a href="https://baz.racunalnicek.ga/zaposleni/moj_racun">Moj ra�un</a>
      <a href="https://baz.racunalnicek.ga/prijava/logout.php">Odjava</a>
    </div>
  </div> 
  </div>
  </div>
<?php
}
?>
</body>
</html>